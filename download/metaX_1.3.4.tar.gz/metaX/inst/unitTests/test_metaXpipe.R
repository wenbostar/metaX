

test_rfSelection=function(){
    
    para <- new("metaXpara")
    checkException(metaXpipe())
    checkException(metaXpipe(para))
    
    
}
